import React, { useEffect, useState } from 'react'
import Card from '../card/Card';


export default function Dashboard() {
    const [news, setNews] = useState([]);


    useEffect(() => {

        fetch('https://newsapi.org/v2/top-headlines?country=us&apikey=240d56fcad6743b5a69c9b884f941396&page=1)', { 

        })
        .then(result=> result.json())
            .then(output => {
                console.log(output);

                setNews(output.articles);
            })

        })

    return (
        <div className="row">
            <h3 className='text-center text-bold text-danger'>News Headlines</h3>
            {
                
                news.map(obj => 
                
                <Card key={obj.id} image={obj.urlToImage} title={obj.title} author={obj.author} url={obj.url} description={obj.description}/>)
            
            }
            
            <div className='col-md-4 mt-2'>
            </div>
        </div>
    );



}