// import { render, screen } from '@testing-library/react';
import {render as renderer, unmountComponentAtNode} from 'react-dom'

import '@testing-library/jest-dom/extend-expect';
// import React from 'react'
import Card from '../Components/card/Card';
import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom'
describe('Testing Card component', () => {
    test('Demo test', () => { console.log('Test executed'); })
})
test("Should Have Read later in card component", ()=>{
    render(<Card/>)
    expect(screen.getByText("Read later")).toBeInTheDocument()
 })

test('section is not in Card component', () => {
    render(<Card />)
    const sectionElem = screen.queryByRole('section', { name: 'section' })
    expect(sectionElem).not.toBeInTheDocument()
})

test('main is not in Card component', () => {
    render(<Card />)
    const sectionElem = screen.queryByRole('main', { name: 'main' })
    expect(sectionElem).not.toBeInTheDocument()
})
test("Should Have Read later in card component", ()=>{
    render(<Card/>)
    expect(screen.getByText("Read later")).toBeInTheDocument()
 })
 
export default Card;

