import React from 'react'

export default function Footer() {
  return (
    <div className='container bg-dark text-light'>

            <p className='text-center mt-2'>Copyright @WION Media Pvt Ltd 2022</p>
    </div>
  )
}

