import React, { useEffect, useState } from 'react'
//import { Link } from 'react-bootstrap/lib/Navbar';
import { useNavigate } from 'react-router-dom';
import DisplayCard from '../displayCard/DisplayCard';



export default function ReadNow() {
    const [news, setNews] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        

        fetch('http://localhost:3001/auth/v1/isAuthenticated', {
            method: "POST",
            headers: {
                "Authorization": `Bearer ${localStorage.getItem('token')}`
            }
        })
            .then(result => result.json())
            .then(output => {
                console.log(output);
                if (!output.isAuthenticated) {
                    navigate("/login");
                }
                else {
                    fetch('https://newsapi.org/v2/top-headlines?country=in&apikey=71d8511839fb48d68c54c08739c27084&page=1', {
                        headers: {
                            "Authorization": `Bearer ${localStorage.getItem('token')}`
                        }
                    })
                        .then(result => result.json())
                        .then(output => setNews(output.articles))
                }

                //setNews(output.articles);
            }).catch(error => (error.message))

    }, [])

    function logout() {
        localStorage.clear("token");
    }

    console.log(localStorage.getItem("token"));

    return (
        <div>
            {/* <h5>Welcome {sessionStorage.getItem('token')}</h5> */}
            <div className="d-flex m-3">
                <a className="btn btn-outline-success offset-md-11 text-light bg-danger" onClick={logout} type="submit" href='/login'>Logout</a>
            </div>

            <div className="row">

                <h2 className='text-center text-bold text-danger'>News Headlines</h2>
                {/* <h4 className='text-left text-primary'>Welcome {sessionStorage.getItem('token')}</h4> */}


               
                {

                    news.map(obj =>

                        <DisplayCard key={obj.id} image={obj.urlToImage} title={obj.title} author={obj.author} url={obj.url} description={obj.description} />)

                }

                <div className='col-md-4 mt-2'>
                </div>
            </div>
        </div>
    );


}

