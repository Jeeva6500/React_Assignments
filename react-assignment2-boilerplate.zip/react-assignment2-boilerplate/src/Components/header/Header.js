import React from 'react'

export default function Header() {
    return (
        <div>
            <nav className="navbar navbar-expand-lg bg-info">
                <div className="container-fluid">
                    <a className="navbar-brand" href="#"><h3>DECCAN Chronicle<sup>®</sup></h3></a>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                            <li className="nav-item">
                                <a className="nav-link active text-size-larger" aria-current="page" href="/register">Home</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="#">News</a>
                            </li>

                            <li className="nav-item">
                                <a className="nav-link" href="#">Debate</a>
                            </li>

                            <li className="nav-item">
                                <a className="nav-link" href="#">Magazines</a>
                            </li>


                            <li className="nav-item dropdown">
                                <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Sports
                                </a>
                                <ul className="dropdown-menu">
                                    <li><a className="dropdown-item" href="#">Cricket</a></li>
                                    <li><hr className="dropdown-divider" /></li>
                                    <li><a className="dropdown-item" href="#">Football</a></li>
                                    <li><hr className="dropdown-divider" /></li>
                                    <li><a className="dropdown-item" href="#">Asian Games</a></li>
                                </ul>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="#">Contact us</a>
                            </li>
                        </ul>
                        <form className="d-flex" role="search">
                        <a className="btn btn-outline-dark me-3" type="submit" href='/register' >Register</a>
                        <a className="btn btn-outline-dark me-3" type="submit" href='/login' >Login</a>
                            <button className="btn btn-outline-dark me-3" type="submit">Dashboard</button>
                            <button className="btn btn-outline-dark" type="submit">Read now</button>

                        </form>

                    </div>
                </div>
            </nav>
        </div>
    )
}
