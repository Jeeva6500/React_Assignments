import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom'
import Card from '../Components/card/Card';
test('should return a Text from Card Component',()=> {
    render(<Card />);
    const searchtext = screen.getByText(/Card/);
    expect(searchtext).toBeInTheDocument();
  })