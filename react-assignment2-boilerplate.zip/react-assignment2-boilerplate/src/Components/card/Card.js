import React from 'react'

export default function Card() {
  return (
    <div>
        <h2>Card</h2>
        </div>
  )
}
