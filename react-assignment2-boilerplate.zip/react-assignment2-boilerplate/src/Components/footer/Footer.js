import React from 'react'

export default function Footer() {
  return (
    <div className="mt-12 text-center bg-secondary">
        <p>Copy right @ DB Media Pvt Ltd 2022</p>

    </div>
  )
}
