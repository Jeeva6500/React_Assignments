// import { render, screen } from '@testing-library/react';
import {render as renderer, unmountComponentAtNode} from 'react-dom'
// import React from 'react'
import Footer from '../Components/footer/Footer';
//import { toHaveStyle } from '@testing-library/jest-dom'
import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom'
// expect.extend({ toHaveStyle })
describe("Testing Footer component",()=>{
    let element;
    beforeEach(()=>{
      element= document.createElement("div")
      document.body.appendChild(element)
    })
    afterEach(()=>{
        unmountComponentAtNode(element)
        element.remove()
        element=null
       })
    test("Demo test",()=>{
        console.log("Test executed");
    })
       it("Should have 1 p in footer component",()=>{
        renderer(<Footer />,element)
        const count=element.getElementsByTagName('p').length
        expect(count).toBe(1)
})
it("Should have 1 div in footer component",()=>{
    renderer(<Footer />,element)
    const count=element.getElementsByTagName('div').length
    expect(count).toBe(1)
})
})