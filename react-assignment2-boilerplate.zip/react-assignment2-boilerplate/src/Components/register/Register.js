
import { useFormik } from 'formik';
import React from 'react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import * as yup from 'yup'
import YupPassword from 'yup-password'
YupPassword(yup)

export default function Register() {

  const [error, setError] = useState('')
  const navigate = useNavigate();

  const formik = useFormik({
    initialValues: {
      username: '',
      password: '',
      fname: '',
      lname: '',
      phone: '',
      city: '',
      pincode: ''

    },
    onSubmit: values => {
      
      fetch('http://localhost:3000/userDatabase', {
        method: "POST",
        headers: {
          "content-Type": 'application/json'
        },
        body: JSON.stringify(values)
      })
        .then(res => res.json())
        .then(data => {
          console.log("else executed");
          alert('Registration completed')
          navigate('/login')
        })

        .catch(error => setError(error.message));


    },
    validationSchema: yup.object().shape({
      username: yup.string().email('Enter valid email id (eg: abc@xyz.com)').required('Email id should not be blank'),
      password: yup.string().password().min(8, "Password should be minimum 8 characters").required('Password should not be blank'),
      fname: yup.string().required('First name should not be blank'),
      lname: yup.string().required('Last name should not be blank'),
      phone: yup.string().min(10).max(10, "Enter valid phone number").required('Phone number should not be blank'),
      city: yup.string().required('City should not be blank'),
      pincode: yup.string().min(6).max(6, 'Enter valid pincode').required('Pincode should not be blank'),
    })

  })

  return (
    <div className='row'>
      <div className='col-md-4 offset-md-4'>
        <div className="bg-warning text-dark mt-2 mb-2 py-2 rounded text-center">
          <h2>Register</h2>
        </div>
        {
          error !== '' ? <span>{error}</span> : <span></span>
        }
        <form onSubmit={formik.handleSubmit}>
          <input onChange={formik.handleChange} onBlur={formik.handleBlur} id="username" name="username" className='form-control form-control-sm' type="text" placeholder='Enter valid email id' ></input>
          {
            formik.errors.username && formik.touched.username ? <span className='text-danger'>{formik.errors.username}</span> : null
          }

          <input onChange={formik.handleChange} onBlur={formik.handleBlur} id="password" name="password" className='form-control form-control-sm' type="password" placeholder='Enter valid password' ></input>
          {
            formik.errors.password && formik.touched.password ? <span className='text-danger'>{formik.errors.password}</span> : null
          }

          <input onChange={formik.handleChange} onBlur={formik.handleBlur} id="fname" name="fname" className='form-control form-control-sm' type="text" placeholder='Enter valid first name' ></input>
          {
            formik.errors.fname && formik.touched.fname ? <span className='text-danger'>{formik.errors.fname}</span> : null
          }

          <input onChange={formik.handleChange} onBlur={formik.handleBlur} id="lname" name="lname" className='form-control form-control-sm' type="text" placeholder='Enter valid last name' ></input>
          {
            formik.errors.lname && formik.touched.lname ? <span className='text-danger'>{formik.errors.lname}</span> : null
          }

          <input onChange={formik.handleChange} onBlur={formik.handleBlur} id="phone" name="phone" className='form-control form-control-sm' type="number" placeholder='Enter valid phone number' ></input>
          {
            formik.errors.phone && formik.touched.phone ? <span className='text-danger'>{formik.errors.phone}</span> : null
          }

          <input onChange={formik.handleChange} onBlur={formik.handleBlur} id="city" name="city" className='form-control form-control-sm' type="text" placeholder='Enter valid city name' ></input>
          {
            formik.errors.city && formik.touched.city ? <span className='text-danger'>{formik.errors.city}</span> : null
          }

          <input onChange={formik.handleChange} onBlur={formik.handleBlur} id="pincode" name="pincode" className='form-control form-control-sm' type="number" placeholder='Enter valid pincode' ></input>
          {
            formik.errors.pincode && formik.touched.pincode ? <span className='text-danger'>{formik.errors.pincode}</span> : null
          }

          <div className='mt-2 text-center'>
            <input className="btn btn-warning" type="submit" value="Register" />
          </div>
        </form>
      </div>
    </div>
  )
}
