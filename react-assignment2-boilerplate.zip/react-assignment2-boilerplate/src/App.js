
import React from "react";
import { Suspense } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Card from "./Components/card/Card";

import Dashboard from "./Components/dashboard/Dashboard";
import DisplayCard from "./Components/displayCard/DisplayCard";
import Footer from "./Components/footer/Footer";
import Header from "./Components/header/Header";
import Login from "./Components/login/Login";
import ReadNow from "./Components/readNow/ReadNow";
import Register from "./Components/register/Register";
//import { ErrorBoundary } from "react-error-boundary";
class App extends React.Component{
  render(){
    
  return (
<BrowserRouter>

<Suspense fallback= {<div><h3 className='text-center'>Loading...</h3></div>}>
<Header/>

<Routes>
  <Route path="/register" element={<Register />}></Route>
  <Route path="/login" element={<Login />}></Route>
  <Route path="/displaycard" element={<DisplayCard />}></Route>
  <Route path="/readnow" element={<ReadNow />}></Route>
  <Route path="/dashboard" element={<Dashboard />}></Route>
  <Route path="/card" element={<Card />}></Route>
 
</Routes>
</Suspense>
<Footer />
</BrowserRouter>

   // please add your code
  );
  }

}
export default App;
