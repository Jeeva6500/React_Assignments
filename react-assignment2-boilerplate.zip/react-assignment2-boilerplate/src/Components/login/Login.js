
import { useFormik } from 'formik';
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'


export default function Login() {

    const navigate = useNavigate();
    const [error, setError] = useState('');

    const formik = useFormik({
        initialValues: {
            username: '',
            password: ''
        },
        onSubmit: values => {
            console.log(values);
            fetch(`http://localhost:3001/auth/v1`, {
                method:"POST",
                headers:{
                    "content-Type":'application/json'
                },
                body: JSON.stringify(values)
                       })
                       .then(res => res.json())
                       .then (data => {
                        localStorage.setItem('token', data.token);
                        console.log(localStorage.getItem('token'));
                        navigate("/displaycard")
                       })
              

        
    } } )

    return (
        <div className='row'>
            <div className="col-md-4 offset-md-4">
                <div className="bg-warning text-dark mt-2 mb-2 rounded text-center">
                    <h3>Login</h3>
                </div>
                {
                    error != '' ? <span className="text-center alert alert-danger">{error}</span> : <span></span>
                }
                <form onSubmit={formik.handleSubmit}>
                    <input onChange={formik.handleChange} onBlur={formik.handleBlur} id='username' name='username' className='form-control form-control-sm' type="text" placeholder='Enter valid email id' />
                    {
                        formik.errors.username && formik.touched.username ? <span className='text-danger'>{formik.errors.username}</span> : null
                    }

                    <input onChange={formik.handleChange} onBlur={formik.handleBlur} id='password' name='password' className='form-control form-control-sm' type="password" placeholder='Enter password' />
                    {
                        formik.errors.password && formik.touched.password ? <span className='text-danger'>{formik.errors.password}</span> : null
                    }

                    <div className="mt-2 text-center">
                        <input className='btn btn-warning' type="submit" value="Login" />
                    </div>

                </form>
            </div>


        </div>
    )
}

