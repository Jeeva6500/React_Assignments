import React, { useState } from 'react'

export default function Card(props) {

  const [read, setRead] = useState([]);

  function readLater() {
    const obj = {
      'url': `${props.url}`,
      'description': `${props.description}`

    }

fetch('http://localhost:3000/newsdatabase',{
    method: "POST",
            headers: {
                "content-Type": "application/json"
            },
            body: JSON.stringify(obj)
        }).then(result => {
            console.log(result);
            alert('Saved for later');
        }).catch(error => alert(error))

}

  return (
    
    <div className='col-md-4 mt-2'>
      <div className="card mt-2" style={{ 'width': '18rem', 'height': '21rem' }}>
        <img src={props.image} className="card-img-top" style={{ 'width': '18rem', 'height': '8rem' }} alt="..." />
        
        <div className="card-body">
          <p className="card-title">{props.title}.   Author:{props.author}</p>
          <div className='mt-2 text-center'>
            <a href="#" className="btn btn-primary" type="submit" onClick={readLater}>Read later</a>
          </div>
        </div>
      </div>
    </div>
   


  )
}
